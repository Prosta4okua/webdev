<!doctype html>
<html lang="en">
<body>
<div class="row center">
       <span>
           You don't have enough permissions to view this page, please <a href="index.php">Login</a>
       </span>
</body>
</html>